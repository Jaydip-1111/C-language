if(a>b && a>c){
            //     printf("a-%d is maximum",a);
            // }else if(b>c){
            //     printf("b-%d is maximum",b);
            // }
            // else{
            //     printf("c-%d is maximum",c);
            // }