void main(){
            printf(" - - - -\n");
            printf("|\t|\n");
            printf("|\t|\n");
            printf("|jaydip |\n");
            printf("|\t|\n");
            printf("|\t|\n");
            printf(" - - - -\n");
            printf("\n\n\n");

            printf(" -  -  -\n");
            printf("|\t|\n");
            printf("j\t|\n");
            printf("a\t|\n");
            printf("y\t|\n");
            printf("d\t|\n");
            printf("i\t|\n");
            printf("p\t|\n");
            printf("|\t|\n");
            printf(" -  -  -\n");
            printf("\n\n\n");


            printf("*\n");
            printf("*  *\n");
            printf("*  *  *\n");
            printf("*  *\n");
            printf("*\n");
            printf("\n\n\n");


            printf("*\n");
            printf("*\n");
            printf("*                                      * *\n");
            printf("*                                    *     *\n");
            printf("*         *    *                   *\n");
            printf("*       *         *              *\n");
            printf("*     *              *         * \n");
            printf("*   *                   *    *\n");
            printf("*\n");
            printf("\n\n\n");
            
}