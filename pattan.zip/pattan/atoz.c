// a pattan
void main()
{
   printf("* * * * *\n");
   printf("*\t*\n");
   printf("* * * * *\n");
   printf("*\t*\n");
   printf("*\t*\n");
   printf("*\t*\n");
   printf("*\t*\n");
   printf("\n\n\n");

   // b pattan

   printf("*  *  *\n");
   printf("*\t*\n");
   printf("*     *\n");
   printf("* * *\n");
   printf("*    *\n");
   printf("*\t*\n");
   printf("*  *  *\n");
   printf("\n\n\n");

   // c pattan

   printf("*  *   *  *\n");
   printf("*\n");
   printf("*\n");
   printf("*\n");
   printf("*\n");
   printf("*\n");
   printf("*  *   *  *");
   printf("\n\n\n");

   // d pattan

   printf("*   *\n");
   printf("*     *\n");
   printf("*\t*\n");
   printf("*        *\n");
   printf("*\t*\n");
   printf("*     *\n");
   printf("*   *\n");
   printf("\n\n\n");

   // e pattan

   printf("*  *  *  *\n");
   printf("*\n");
   printf("*\n");
   printf("*  *  *  *\n");
   printf("*\n");
   printf("*\n");
   printf("*  *  *  *\n");
   printf("\n\n\n");

   // f pattan

   printf("*   *   *   *\n");
   printf("*\n");
   printf("*\n");
   printf("*  *  *  *\n");
   printf("*\n");
   printf("*\n");
   printf("*\n");
   printf("\n\n\n");

   // g pattan

   printf("  *  *  *\n");
   printf("*\t*\n");
   printf("*\n");
   printf("*   * * *\n");
   printf("*\t*\n");
   printf("*\t*\n");
   printf("  *  *  *");
   printf("\n\n\n");

   // h pattan

   printf("*\t*\n");
   printf("*\t*\n");
   printf("*\t*\n");
   printf("* * * *\n");
   printf("*\t*\n");
   printf("*\t*\n");
   printf("*\t*\n");
   printf("\n\n\n");

   // i pattan

   printf("* * * * *\n");
   printf("    *\n");
   printf("    *\n");
   printf("    *\n");
   printf("    *\n");
   printf("    *\n");
   printf("* * * * *\n");
   printf("\n\n\n");

   // j pattan

   printf("* * * * *\n");
   printf("    *\n");
   printf("    *\n");
   printf("    *\n");
   printf("    *\n");
   printf("    *\n");
   printf("*   *\n");
   printf("  * ");
   printf("\n\n\n");

   // k pattan

   printf("*\t*\n");
   printf("*    *\n");
   printf("*  *\n");
   printf("* *\n");
   printf("*  *\n");
   printf("*    *\n");
   printf("*\t*\n");
   printf("\n\n\n");

   // l pattan

   printf("*\n");
   printf("*\n");
   printf("*\n");
   printf("*\n");
   printf("*\n");
   printf("*\n");
   printf("* * * *\n");
   printf("\n\n\n");

   // m pattan

   printf("*\t *\n");
   printf("*  *  *  *\n");
   printf("*    *   *\n");
   printf("*\t *\n");
   printf("*\t *\n");
   printf("*\t *\n");
   printf("*\t *\n\n");

   // n pattan

   printf("*\t*\n");
   printf("*\t*\n");
   printf("* *\t*\n");
   printf("*   *   *\n");
   printf("*     * *\n");
   printf("*\t*\n");
   printf("*\t*\n\n");

   // o pattan

  printf("  * * *\n");
  printf("*\t*\n");
  printf("*\t*\n");
  printf("*\t*\n");
  printf("*\t*\n");
  printf("*\t*\n");
  printf("  * * *\n\n");

   // p pattan

   printf("* * * *\n");
  printf("*\t*\n");
  printf("*\t*\n");
  printf("* * * *\n");
  printf("*\n");
  printf("*\n");
  printf("*\n");
  printf("*\n\n");

  // Q pattern

  printf("  * * *\n");
  printf("*\t*\n");
  printf("*\t*\n");
  printf("*\t*\n");
  printf("*   *   *\n");
  printf("*      *\n");
  printf("  * *     *\n\n");

  // R pattern

  printf("************\n");
  printf("*\t   *\n");
  printf("*\t   *\n");
  printf("*\t   *\n");
  printf("************\n");
  printf("* *\n");
  printf("*   *\n");
  printf("*     *\n");
  printf("*\t *\n");
  printf("*\t   *\n\n");

  //  S pattern

  printf("  *  *  *  *\n");
  printf("*\n");
  printf("*\n");
  printf("  *  *  *\n");
  printf("\t   *\n");
  printf("\t   *\n");
  printf("*  *  *  *\n\n");

  // T pattern

  printf("***********\n");
  printf("     * \n");
  printf("     * \n");
  printf("     * \n");
  printf("     * \n");
  printf("     * \n");
  printf("     * \n\n");

  //  U pattern

  printf("*\t*\n");
  printf("*\t*\n");
  printf("*\t*\n");
  printf("*\t*\n");
  printf("*\t*\n");
  printf("*\t*\n");
  printf("  * * *\n\n");

  // V pattern

  printf("*\t*\n");
  printf("*\t*\n");
  printf("*\t*\n");
  printf("*\t*\n");
  printf("*\t*\n");
  printf("  *   *\n");
  printf("    *\n\n");

  // W pattern

  printf("*\t *\n");
  printf("*\t *\n");
  printf("*\t *\n");
  printf("*\t *\n");
  printf("*\t *\n");
  printf("*  *  *  *\n");
  printf("*    *   *\n\n");

  // X pattern

  printf("*\t*\n");
  printf("  *   *\n");
  printf("   * *\n");
  printf("    *\n");
  printf("   * *\n");
  printf("  *   *\n");
  printf("*\t*\n\n");

  // Y pattern

  printf("*\t*\n");
  printf("  *   *\n");
  printf("   * *\n");
  printf("    *\n");
  printf("    *\n");
  printf("    *\n");
  printf("    *\n\n");

  // Z pattern

  printf("*  *  *  *  *\n");
  printf("\t  *\n");
  printf("\t*\n");
  printf("      *\n");
  printf("    *\n");
  printf("  *\n");
  printf("*  *  *  *  *\n\n");
}