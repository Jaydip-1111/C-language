#include<stdio.h>
int main(){
           
           printf("\t\t*\t*\n");
           printf("\t*\t    *\n");
           printf("  *\t       *\n");
           printf("\t*\t    *\n");
           printf("\t       *\t*\n");
}