// Program list to include all Type of operator

// (1) find size of variable type

#include<stdio.h>
#include<conio.h>

void main(){
    int a;
    float b;
    char c;
    double d;
    
    printf("%d \n", sizeof(a));
    printf("%d \n", sizeof(b));
    printf("%d \n", sizeof(c));
    printf("%d \n", sizeof(d));
}