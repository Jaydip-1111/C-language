// (5) perform below operation and store in total variable.

#include <stdio.h>
#include <conio.h>

void main(){
    int a=8,total=25;
     
    total +=a;
    printf("New total is 1 %d \n",total);
    total -=a;
    printf("New total is 2 %d \n",total);
    total *=a;
    printf("New total is 3 %d \n",total);
    total /=a;
    printf("New total is 4 %d \n",total);
    total %=a;
    printf("New total is 5 %d \n",total);
                                                                                                    
}