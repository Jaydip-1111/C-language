#include<stdio.h>
int main()
  {    
       int age,b,c;
       printf("Enter age:");
       scanf("%d",&age);

       (age>=18)?printf("u r eligible for vote"):printf("u r not eligible for vote");
       return 0;
}