#include<stdio.h>
int main(){
             int age,b,c;
             printf("Enter Age:-");
             scanf("%d",&age);
             (age>=18)?printf("You Are Eligible for vote"):printf("You Are  Not Eligible for vote");
             return 0;

}