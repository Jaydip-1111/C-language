#include<stdio.h>
int main(){
              int a,b;

              printf("\nEnter the number:-");
              scanf("%d",&a);

              b = a * a;
              printf("number of square :%d",b);

              return 0;

}