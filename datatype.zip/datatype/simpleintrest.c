#include<stdio.h>
int main(){
         float p = 5,r = 5, t = 5;
         float si = (p * r * t)/100;
         printf("simple interst =%f\n",si);
         return 0;
}