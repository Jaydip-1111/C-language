#include<stdio.h>
int main(){
           printf("Name:-Jaydip Makwana P\n");
           printf("Gender:-Male\n");
           printf("Age:-25\n");
           printf("Village:-Panshina\n");
           printf("City:-Limbdi\n");
           printf("Dist:-Surendranagar\n");
           printf("Study:-Red&White Multimedia Education Navrangpura\n");
           printf("Grid:-F251");
}